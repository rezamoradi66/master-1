@echo off
setlocal EnableExtensions
rem ============================================================
rem  CBM Daily Database Backup  (CapitalBudget / SQL Server)
rem  Part of the CBM Backup Kit  (guide: README-backup.txt)
rem
rem  - Reads sql.* settings from ..\..\server\config.json
rem    (single source of truth - no duplicate config here)
rem  - Backup file:  C:\CBM-Backups\<DB>_<yyyyMMdd_HHmmss>.bak
rem  - Retention:    deletes *.bak older than RETAIN_DAYS (30)
rem  - Log:          C:\CBM-Backups\backup-log.txt
rem  - Exit code 0 = success / 1 = failure (Task Scheduler shows it)
rem
rem  NOTE: keep this file ASCII-only (cmd.exe codepage safety).
rem  Persian step-by-step guide: README-backup.txt (same folder)
rem ============================================================

set "CFG=%~dp0..\..\server\config.json"
set "BDIR=C:\CBM-Backups"
set "RETAIN_DAYS=30"
set "LOG=%BDIR%\backup-log.txt"

if not exist "%CFG%" (
  echo [%date% %time%] ERROR: config.json not found: "%CFG%" >> "%LOG%"
  exit /b 1
)
if not exist "%BDIR%" mkdir "%BDIR%" >nul 2>&1

where sqlcmd >nul 2>&1
if errorlevel 1 (
  echo [%date% %time%] ERROR: sqlcmd.exe not found in PATH. Install SQL Server command line tools ^(see README-backup.txt, section Troubleshooting^). >> "%LOG%"
  exit /b 1
)

rem ---- read sql settings from config.json (via PowerShell) ----
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "$c=(Get-Content -Raw -LiteralPath '%CFG%')|ConvertFrom-Json|Select-Object -ExpandProperty sql; if($c.instanceName){$s=$c.server+'\'+$c.instanceName}else{$s=$c.server; if($c.port -and $c.port -ne 1433){$s=('{0},{1}' -f $c.server,$c.port)}}; $s"`) do set "SQLS=%%i"
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "(Get-Content -Raw -LiteralPath '%CFG%')|ConvertFrom-Json|Select-Object -ExpandProperty sql|Select-Object -ExpandProperty database"`) do set "DB=%%i"
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "(Get-Content -Raw -LiteralPath '%CFG%')|ConvertFrom-Json|Select-Object -ExpandProperty sql|Select-Object -ExpandProperty authType"`) do set "AUTHTYPE=%%i"
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "(Get-Content -Raw -LiteralPath '%CFG%')|ConvertFrom-Json|Select-Object -ExpandProperty sql|Select-Object -ExpandProperty user"`) do set "SQLU=%%i"
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "(Get-Content -Raw -LiteralPath '%CFG%')|ConvertFrom-Json|Select-Object -ExpandProperty sql|Select-Object -ExpandProperty password"`) do set "SQLP=%%i"

if not defined SQLS ( echo [%date% %time%] ERROR: cannot read sql.server from config.json >> "%LOG%" & exit /b 1 )
if not defined DB   ( echo [%date% %time%] ERROR: cannot read sql.database from config.json >> "%LOG%" & exit /b 1 )

set "AUTH=-E"
if /i "%AUTHTYPE%"=="sql" set "AUTH=-U %SQLU% -P"%SQLP%""

rem ---- timestamp (locale-independent via PowerShell) ----
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"`) do set "STAMP=%%i"
set "BAK=%BDIR%\%DB%_%STAMP%.bak"

echo [%date% %time%] START backup  db=%DB%  server=%SQLS%  auth=%AUTHTYPE% >> "%LOG%"

rem ---- 1) backup: try compressed first, auto-retry plain (SQL Express has no backup compression) ----
sqlcmd -S "%SQLS%" %AUTH% -d master -Q "BACKUP DATABASE [%DB%] TO DISK=N'%BAK%' WITH COMPRESSION, CHECKSUM, INIT, NAME=N'CBM daily backup'" -b -l 60 >> "%LOG%" 2>&1
if errorlevel 1 (
  echo [%date% %time%] WARN: compressed backup failed - retrying without COMPRESSION ^(SQL Express?^) >> "%LOG%"
  sqlcmd -S "%SQLS%" %AUTH% -d master -Q "BACKUP DATABASE [%DB%] TO DISK=N'%BAK%' WITH CHECKSUM, INIT" -b -l 60 >> "%LOG%" 2>&1
  if errorlevel 1 goto :fail
)

rem ---- 2) verify the backup file is readable/restorable ----
sqlcmd -S "%SQLS%" %AUTH% -d master -Q "RESTORE VERIFYONLY FROM DISK=N'%BAK%'" -b >> "%LOG%" 2>&1
if errorlevel 1 goto :fail

rem ---- 3) retention: delete *.bak files older than RETAIN_DAYS ----
forfiles /p "%BDIR%" /m *.bak /d -%RETAIN_DAYS% /c "cmd /c if @isdir==FALSE del /f /q @path" >nul 2>&1

echo [%date% %time%] OK  backup=%BAK% >> "%LOG%"
endlocal & exit /b 0

:fail
echo [%date% %time%] FAILED  backup=%BAK% >> "%LOG%"
endlocal & exit /b 1
