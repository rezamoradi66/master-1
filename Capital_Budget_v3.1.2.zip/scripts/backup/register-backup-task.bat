@echo off
rem ============================================================
rem  Registers the Windows Scheduled Task for the CBM daily
rem  database backup.  (CBM Backup Kit - see README-backup.txt)
rem
rem  Task name : CBM-Backup-Daily
rem  Schedule  : every day at 02:30 (server local time)
rem  Runs as   : SYSTEM  (no password needed)
rem
rem  --> Run AS ADMINISTRATOR (right-click > Run as administrator)
rem ============================================================
net session >nul 2>&1
if errorlevel 1 (
  echo Please run this file as Administrator ^(right-click - Run as administrator^).
  pause
  exit /b 1
)
schtasks /Create /F /TN "CBM-Backup-Daily" /TR "\"%~dp0backup-daily.bat\"" /SC DAILY /ST 02:30 /RU SYSTEM /RL HIGHEST
if errorlevel 1 (
  echo.
  echo FAILED to create the scheduled task. See README-backup.txt ^(Troubleshooting^).
  pause
  exit /b 1
)
echo.
echo Done. Scheduled task "CBM-Backup-Daily" created (daily at 02:30, as SYSTEM).
echo.
echo Quick checks:
echo   Run it now :  schtasks /Run /TN "CBM-Backup-Daily"
echo   Check state:  schtasks /Query /TN "CBM-Backup-Daily"
echo   Result log :  C:\CBM-Backups\backup-log.txt
echo   Remove task:  unregister-backup-task.bat (same folder)
echo.
pause
