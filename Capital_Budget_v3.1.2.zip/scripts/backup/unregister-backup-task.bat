@echo off
rem ============================================================
rem  Removes the "CBM-Backup-Daily" scheduled task.
rem  (CBM Backup Kit - see README-backup.txt)
rem  --> Run AS ADMINISTRATOR (right-click > Run as administrator)
rem ============================================================
net session >nul 2>&1
if errorlevel 1 (
  echo Please run this file as Administrator ^(right-click - Run as administrator^).
  pause
  exit /b 1
)
schtasks /Delete /TN "CBM-Backup-Daily" /F
echo.
echo Task "CBM-Backup-Daily" removed (existing backup files in C:\CBM-Backups are kept).
pause
