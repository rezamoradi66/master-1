@echo off
chcp 65001 >nul
:: ═══════════════════════════════════════════════════════════════
::  firewall-rule.bat — باز کردن پورت سامانه در فایروال ویندوز
::  ⚠ با Run as administrator اجرا کنید.
::  اگر در config.json پورت دیگری تعریف کرده‌اید، عدد زیر را هم عوض کنید.
:: ═══════════════════════════════════════════════════════════════
set PORT=8080

echo باز کردن پورت %PORT% فقط برای شبکه داخلی (Private/Domain)...
netsh advfirewall firewall delete rule name="CBM Budget Server" >nul 2>nul
netsh advfirewall firewall add rule name="CBM Budget Server" dir=in action=allow protocol=TCP localport=%PORT% profile=domain,private

if errorlevel 1 (
  echo [خطا] اجرای دستور نیازمند Run as administrator است.
  pause
  exit /b 1
)
echo.
echo [موفق] پورت %PORT% برای شبکه داخلی باز شد.
echo برای محدودسازی به یک زیرشبکه مشخص، راهنمای بخش ۹ راهنمای PDF را ببینید.
pause
