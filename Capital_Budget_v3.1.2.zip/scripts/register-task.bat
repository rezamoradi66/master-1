@echo off
chcp 65001 >nul
:: ═══════════════════════════════════════════════════════════════
::  register-task.bat — ثبت سرویس سامانه برای اجرای خودکار پس از
::  ری‌استارت سرور (Windows Task Scheduler)
::  ⚠ این فایل را باید با Run as administrator اجرا کنید.
::  قبل از اجرا: مقدار INSTALL_DIR زیر را به مسیر واقعی بسته تغییر دهید.
:: ═══════════════════════════════════════════════════════════════

set INSTALL_DIR=C:\cbm
set TASK_NAME=CBM_BudgetServer

echo ثبت وظیفه «%TASK_NAME%» برای اجرای خودکار سامانه...
echo مسیر نصب: %INSTALL_DIR%
echo.

:: حذف نسخه قبلی در صورت وجود
schtasks /Delete /TN "%TASK_NAME%" /F >nul 2>nul

:: ایجاد وظیفه: اجرای start-server-hidden.vbs هنگام راه‌اندازی سیستم با حساب SYSTEM
schtasks /Create /TN "%TASK_NAME%" /SC ONSTART /RU SYSTEM /RL HIGHEST /TR "wscript.exe \"%INSTALL_DIR%\scripts\start-server-hidden.vbs\""

if errorlevel 1 (
  echo.
  echo [خطا] ثبت وظیفه ناموفق بود. حتماً این فایل را با Run as administrator اجرا کنید.
  pause
  exit /b 1
)

echo.
echo [موفق] وظیفه ثبت شد. پس از هر ری‌استارت سرور، سرویس سامانه به‌صورت خودکار اجرا می‌شود.
echo تست فوری (اجراهای دستی):  schtasks /Run /TN "%TASK_NAME%"
echo بررسی وضعیت:              schtasks /Query /TN "%TASK_NAME%"
echo حذف وظیفه:                register-task.bat نیست — از unregister-task.bat استفاده کنید.
pause
