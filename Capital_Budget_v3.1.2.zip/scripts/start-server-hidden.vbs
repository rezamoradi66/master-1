' ═══════════════════════════════════════════════════════════
'  start-server-hidden.vbs — اجرای بی‌پنجره سرور سامانه
'  (به‌کاررفته در Task Scheduler — register-task.bat)
' ═══════════════════════════════════════════════════════════
Option Explicit
Dim WshShell, baseDir, fso
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
baseDir = fso.GetParentFolderName(WScript.ScriptFullName) ' ...\scripts
baseDir = fso.GetParentFolderName(baseDir)                ' root پکیج
WshShell.CurrentDirectory = baseDir & "\server"
' ایجاد پوشه لاگ در صورت نبود
If Not fso.FolderExists(WshShell.CurrentDirectory & "\logs") Then
  fso.CreateFolder(WshShell.CurrentDirectory & "\logs")
End If
WshShell.Run "cmd /c node server.js >> logs\service.log 2>&1", 0, False
