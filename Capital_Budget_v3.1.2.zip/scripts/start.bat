﻿@echo off
chcp 65001 >nul
title سامانه مدیریت بودجه سرمایه‌ای — سرویس پایگاه داده
cd /d "%~dp0..\server"

echo ════════════════════════════════════════════════════════
echo   سامانه مدیریت بودجه سرمایه‌ای - اجرای سرور
echo ════════════════════════════════════════════════════════
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [خطا] Node.js نصب نیست یا در PATH نیست.
  echo نصب Node.js LTS مطابق بخش ۴ راهنمای PDF الزامی است.
  pause
  exit /b 1
)

node --version
echo.
echo در حال راه‌اندازی... (برای توقف Ctrl+C)
echo آدرس دسترسی: http://localhost:8080  ^|  از شبکه: http://IP-سرور:8080
echo.
node server.js
echo.
echo [توجه] سرور متوقف شد. اگر خطای پیکربندی می‌ببینید، فایل server\config.json را مطابق راهنمای PDF تکمیل کنید.
pause
