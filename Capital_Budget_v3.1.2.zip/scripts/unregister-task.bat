@echo off
chcp 65001 >nul
:: حذف وظیفه اجرای خودکار سامانه — با Run as administrator
set TASK_NAME=CBM_BudgetServer
schtasks /Delete /TN "%TASK_NAME%" /F
if errorlevel 1 (
  echo [خطا] حذف وظیفه ناموفق بود یا وظیفه وجود ندارد.
) else (
  echo [موفق] وظیفه اجرای خودکار حذف شد.
)
pause
