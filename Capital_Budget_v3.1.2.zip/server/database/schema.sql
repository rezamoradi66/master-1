/* ================================================================
   schema.sql — ساختار پایگاه داده سامانه مدیریت بودجه سرمایه‌ای
   اجرا در SSMS: ابتدا USE دستور زیر را باز کنید، سپس کل اسکریپت را Execute کنید.
   (سرویس Node.js هنگام راه‌اندازی همین ساختار را به‌صورت خودکار نیز ایجاد می‌کند؛
    این اسکریپت برای اجرای دستی/مدیریت‌محور ارائه شده است.)
   ================================================================ */
-- USE CapitalBudget;  -- در صورت نیاز باز کنید
GO

IF OBJECT_ID(N'dbo.CBM_Document', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.CBM_Document(
    Id        INT            NOT NULL CONSTRAINT PK_CBM_Document PRIMARY KEY,
    Doc       NVARCHAR(MAX)  NOT NULL,
    Version   BIGINT         NOT NULL CONSTRAINT DF_CBM_Document_Version DEFAULT(0),
    UpdatedBy NVARCHAR(128)  NULL,
    UpdatedAt DATETIME2(3)   NOT NULL CONSTRAINT DF_CBM_Document_UpdatedAt DEFAULT SYSUTCDATETIME()
  );
END;
GO

IF OBJECT_ID(N'dbo.CBM_DocHistory', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.CBM_DocHistory(
    Id        BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CBM_DocHistory PRIMARY KEY,
    Version   BIGINT         NOT NULL,
    Doc       NVARCHAR(MAX)  NOT NULL,
    UpdatedBy NVARCHAR(128)  NULL,
    UpdatedAt DATETIME2(3)   NOT NULL CONSTRAINT DF_CBM_DocHistory_UpdatedAt DEFAULT SYSUTCDATETIME()
  );
  CREATE INDEX IX_CBM_DocHistory_Id ON dbo.CBM_DocHistory(Id DESC);
END;
GO

IF OBJECT_ID(N'dbo.CBM_Credentials', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.CBM_Credentials(
    Username  NVARCHAR(128)  NOT NULL CONSTRAINT PK_CBM_Credentials PRIMARY KEY,
    PwdHash   NVARCHAR(512)  NULL,
    LegacyPh  NVARCHAR(64)   NULL,
    UpdatedAt DATETIME2(3)   NOT NULL CONSTRAINT DF_CBM_Credentials_UpdatedAt DEFAULT SYSUTCDATETIME()
  );
END;
GO

IF OBJECT_ID(N'dbo.CBM_Sessions', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.CBM_Sessions(
    TokenHash CHAR(64)       NOT NULL CONSTRAINT PK_CBM_Sessions PRIMARY KEY,
    Username  NVARCHAR(128)  NOT NULL,
    CreatedAt DATETIME2(3)   NOT NULL CONSTRAINT DF_CBM_Sessions_CreatedAt DEFAULT SYSUTCDATETIME(),
    LastSeen  DATETIME2(3)   NOT NULL CONSTRAINT DF_CBM_Sessions_LastSeen DEFAULT SYSUTCDATETIME(),
    ExpiresAt DATETIME2(3)   NOT NULL,
    Ip        NVARCHAR(64)   NULL
  );
  CREATE INDEX IX_CBM_Sessions_Username ON dbo.CBM_Sessions(Username);
  CREATE INDEX IX_CBM_Sessions_Expires  ON dbo.CBM_Sessions(ExpiresAt);
END;
GO

IF OBJECT_ID(N'dbo.CBM_AuditLog', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.CBM_AuditLog(
    Id       BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CBM_AuditLog PRIMARY KEY,
    At       DATETIME2(3)   NOT NULL CONSTRAINT DF_CBM_AuditLog_At DEFAULT SYSUTCDATETIME(),
    Username NVARCHAR(128)  NULL,
    Action   NVARCHAR(64)   NOT NULL,
    Success  BIT            NULL,
    Detail   NVARCHAR(400)  NULL,
    Ip       NVARCHAR(64)   NULL
  );
  CREATE INDEX IX_CBM_AuditLog_At ON dbo.CBM_AuditLog(At DESC);
END;
GO

/* ---------- کاربر اختصاصی برنامه (اختیاری — با SQL Authentication) ----------
   رمز قوی انتخاب کنید و همان را در فیلد sql.password فایل config.json بگذارید. */
-- IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'cbm_app')
--   CREATE LOGIN [cbm_app] WITH PASSWORD = N'CHANGE_ME_STRONG_PASSWORD', CHECK_POLICY = ON;
-- GO
-- IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'cbm_app')
--   CREATE USER [cbm_app] FOR LOGIN [cbm_app];
-- GO
-- DROP ROLE IF EXISTS cbm_app_role;
-- CREATE ROLE cbm_app_role AUTHORIZATION dbo;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.CBM_Document   TO cbm_app_role;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.CBM_DocHistory TO cbm_app_role;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.CBM_Credentials TO cbm_app_role;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.CBM_Sessions    TO cbm_app_role;
-- GRANT SELECT, INSERT            ON dbo.CBM_AuditLog        TO cbm_app_role;
-- GRANT ALTER ON SCHEMA::dbo TO cbm_app_role;  -- فقط برای اجرای یک‌باره‌ی ساخت خودکار جداول؛ پس از اولین اجرا می‌توانید حذفش کنید
-- ALTER ROLE cbm_app_role ADD MEMBER [cbm_app];
-- GO

/* ---------- مشاهده گزارش Audit (نمونه) ----------
   SELECT TOP 100 At, Username, Action, Success, Detail, Ip
   FROM dbo.CBM_AuditLog ORDER BY Id DESC;
-------------------------------------------------------------- */
