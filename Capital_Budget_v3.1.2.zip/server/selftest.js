#!/usr/bin/env node
/* ================================================================
   selftest.js — خودآزمایی کامل API با فروشگاه درون‌حافظه
   اجرا:  node selftest.js
   این اسکریپت رفتار تمام مسیرهای API را بدون نیاز به SQL Server آزمایش می‌کند.
   ================================================================ */
'use strict';
process.env.CBM_ALLOW_MEMORY_STORE = '1';

const assert = require('assert');
const crypto = require('crypto');
const http = require('http');

/* --- پیکربندی آزمایشی --- */
const cfg = {
  port: 0, bindHost: '127.0.0.1',
  sql: { server: 'x', port: 1433, database: 'x', authType: 'sql', user: 'x', password: 'x', instanceName: '', encrypt: false, trustServerCertificate: true, connectionTimeout: 5, requestTimeout: 10, poolMax: 3 },
  security: { sessionHours: 1, maxLoginAttempts: 3, lockoutMinutes: 1, pbkdf2Iterations: 2000, historyKeep: 5, cookieName: 'cbm_sid', setupKey: 'TEST-SETUP-KEY-123', allowPublicBootstrap: true, maxBodyMB: 64, logRetentionDays: 60 },
  logs: { dir: 'logs', level: 'error' },
  store: 'memory'
};

const log = require('./lib/log');
log.init(cfg.logs);
const store = require('./lib/store-memory').createMemoryStore(cfg);
const { createRouter } = require('./lib/routes');
const express = require('express');
const app = express();
app.use(express.json({ limit: '64mb' }));
app.use(createRouter({ store, cfg }));
const server = app.listen(0, '127.0.0.1');
let PORT = 0;

/* --- کلاینت HTTP --- */
let cookieJar = '';
function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const options = {
      host: '127.0.0.1', port: PORT, method, path,
      headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {})
    };
    if (cookieJar) options.headers.Cookie = cookieJar;
    if (data) options.headers['Content-Length'] = Buffer.byteLength(data);
    const r = http.request(options, res => {
      const setc = res.headers['set-cookie'];
      if (setc) cookieJar = setc.map(c => c.split(';')[0]).join('; ');
      let buf = '';
      res.on('data', c => buf += c);
      res.on('end', () => {
        let j = null;
        try { j = JSON.parse(buf); } catch (e) {}
        resolve({ status: res.statusCode, json: j, raw: buf });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

/* --- همان hashStr مرورگر برای ساخت ph --- */
function hashStr(str, seed) {
  seed = seed || 7;
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed, i, ch;
  str = String(str);
  for (i = 0; i < str.length; i++) {
    ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

function sampleDoc() {
  return {
    users: [
      { id: 'u1', fn: 'رضا', ln: 'مرادی', uno: '1001', username: 'admin', pos: 'مدیر سایت', mgmtId: '', unitId: '', role: 'admin', roles: ['admin'], active: true, avatar: '', ph: hashStr('1234' + 'admin') },
      { id: 'u2', fn: 'علی', ln: 'محمدی', uno: '1002', username: 'ceo', pos: 'مدیرعامل', mgmtId: '', unitId: '', role: 'ceo', roles: ['ceo'], active: true, avatar: '', ph: hashStr('1234' + 'ceo') }
    ],
    programs: [{ id: 'p1', code: 'PRG-1', title: 'برنامه آزمایشی', sample: false, history: [] }],
    base: { years: [{ y: 1405, active: true }] },
    settings: { systemTitle: 'سامانه آزمایشی', headerText: 'شرکت تست', currency: 'ریال', appearance: { theme: 'navy' }, modules: {} },
    fields: [],
    meta: { migr: 23, version: 2, seq: { prog: 1, micro: 0, user: 2 } }
  };
}

let passed = 0, failed = 0;
function check(name, cond, extra) {
  if (cond) { passed++; console.log('  ✔ ' + name); }
  else { failed++; console.log('  ✘ ' + name + (extra ? ' — ' + JSON.stringify(extra).slice(0, 200) : '')); }
}

(async () => {
  console.log('═══ خودآزمایی API سامانه بودجه (فروشگاه حافظه) ═══');
  await store.init();
  PORT = await new Promise((res, rej) => {
    if (server.listening) return res(server.address().port);
    const t = setTimeout(() => rej(new Error('listen timeout')), 5000);
    server.once('listening', () => { clearTimeout(t); res(server.address().port); });
  });

  /* ۱ — سلامت */
  let r = await req('GET', '/api/health');
  check('GET /api/health → 200', r.status === 200 && r.json.ok && r.json.db === 'ok');

  /* ۲ — برندینگ روی پایگاه خالی */
  r = await req('GET', '/api/public/branding');
  check('GET /api/public/branding (خالی) → empty:true', r.status === 200 && r.json.empty === true);

  /* ۳ — دسترسی به /api/db بدون ورود */
  r = await req('GET', '/api/db');
  check('GET /api/db بدون نشست → 401', r.status === 401);

  /* ۴ — ورود روی پایگاه خالی → شکست */
  r = await req('POST', '/api/auth/login', { username: 'admin', password: '1234' });
  check('ورود روی پایگاه خالی → 401', r.status === 401);

  /* ۵ — bootstrap */
  r = await req('POST', '/api/bootstrap', { doc: sampleDoc() });
  check('POST /api/bootstrap → نسخه ۱', r.status === 200 && r.json.version === 1, r.json);
  r = await req('POST', '/api/bootstrap', { doc: sampleDoc() });
  check('bootstrap دوباره → 409', r.status === 409);

  /* ۶ — برندینگ پس از bootstrap */
  r = await req('GET', '/api/public/branding');
  check('برندینگ → systemTitle', r.status === 200 && r.json.settings && r.json.settings.systemTitle === 'سامانه آزمایشی');

  /* ۷ — ورود با رمز پیش‌فرض (مسیر قدیمی + ارتقا) */
  cookieJar = '';
  r = await req('POST', '/api/auth/login', { username: 'ADMIN', password: '1234' });
  check('ورود admin/1234 (حروف بزرگ نام کاربری) → 200', r.status === 200 && r.json.user.username === 'admin', r.json);
  check('کوکی نشست ست شد', /cbm_sid=/.test(cookieJar));

  /* ۸ — اعتبار PBKDF2 پس از ارتقا */
  const cred = await store.getCredential('admin');
  check('اعتبارنامه PBKDF2 ساخته شد', cred && cred.PwdHash && cred.PwdHash.indexOf('pbkdf2$') === 0);
  cookieJar = '';
  r = await req('POST', '/api/auth/login', { username: 'admin', password: '1234' });
  check('ورود مجدد با مسیر PBKDF2 → 200', r.status === 200);

  /* ۹ — رمز اشتباه */
  cookieJar = '';
  r = await req('POST', '/api/auth/login', { username: 'admin', password: 'wrong' });
  check('رمز اشتباه → 401 با پیام فارسی', r.status === 401 && r.json.error.indexOf('نادرست') !== -1);

  /* ۱۰ — خواندن سند */
  r = await req('POST', '/api/auth/login', { username: 'admin', password: '1234' });
  check('ورود مجدد برای ادامه آزمون', r.status === 200);
  r = await req('GET', '/api/db');
  check('GET /api/db → نسخه ۱ + سند', r.status === 200 && r.json.version === 1 && r.json.doc.programs.length === 1);

  /* ۱۱ — ذخیره با نسخه درست */
  const doc = r.json.doc;
  doc.programs.push({ id: 'p2', code: 'PRG-2', title: 'دوم', sample: false, history: [] });
  r = await req('PUT', '/api/db', { doc, baseVersion: 1 });
  check('PUT /api/db → نسخه ۲', r.status === 200 && r.json.version === 2, r.json);

  /* ۱۲ — تعارض نسخه */
  r = await req('PUT', '/api/db', { doc, baseVersion: 1 });
  check('PUT با نسخه کهنه → 409', r.status === 409 && r.json.conflict === true && r.json.version === 2);

  /* ۱۳ — بازنویسی اجباری */
  r = await req('PUT', '/api/db', { doc, baseVersion: 1, force: true });
  check('PUT force → نسخه ۳', r.status === 200 && r.json.version === 3);

  /* ۱۴ — سند نامعتبر */
  r = await req('PUT', '/api/db', { doc: { foo: 1 }, baseVersion: 3 });
  check('سند نامعتبر → 400', r.status === 400);

  /* ۱۵ — پایش نسخه */
  r = await req('GET', '/api/db/version');
  check('GET /api/db/version → ۳', r.status === 200 && r.json.version === 3);

  /* ۱۶ — نشست */
  r = await req('GET', '/api/session');
  check('GET /api/session → احراز شده', r.status === 200 && r.json.authenticated === true && r.json.user.username === 'admin');

  /* ۱۷ — تغییر رمز خود کاربر */
  r = await req('POST', '/api/users/setpass', { username: 'admin', password: 'newpass99' });
  check('تغییر رمز خود → 200', r.status === 200);
  cookieJar = '';
  r = await req('POST', '/api/auth/login', { username: 'admin', password: 'newpass99' });
  check('ورود با رمز جدید → 200', r.status === 200);
  cookieJar = '';
  r = await req('POST', '/api/auth/login', { username: 'admin', password: '1234' });
  check('ورود با رمز قبلی → 401', r.status === 401);

  /* ۱۸ — setpass کاربر دیگر بدون نقش admin */
  r = await req('POST', '/api/auth/login', { username: 'ceo', password: '1234' });
  check('ورود ceo → 200', r.status === 200);
  r = await req('POST', '/api/users/setpass', { username: 'admin', password: 'hacked' });
  check('ceo اجازه تغییر رمز admin ندارد → 403', r.status === 403);

  /* ۱۹ — قفل حساب پس از تلاش‌های مکرر */
  cookieJar = '';
  let last;
  for (let i = 0; i < 3; i++) last = await req('POST', '/api/auth/login', { username: 'ceo', password: 'bad' });
  check('۳ شکست متوالی → 401', last.status === 401, last.json);
  r = await req('POST', '/api/auth/login', { username: 'ceo', password: '1234' });
  check('تلاش چهارم هنگام قفل → 429', r.status === 429, r.json);

  /* ۲۰ — migrate/import با کلید */
  const doc2 = sampleDoc();
  doc2.programs.push({ id: 'p9', code: 'PRG-9', title: 'مهاجرت', sample: false, history: [] });
  r = await req('POST', '/api/migrate/import', { key: 'TEST-SETUP-KEY-123', doc: doc2 }, { Origin: 'null' });
  check('migrate/import → نسخه جدید', r.status === 200 && r.json.version >= 4, r.json);
  r = await req('POST', '/api/migrate/import', { key: 'bad-key', doc: doc2 });
  check('migrate/import با کلید اشتباه → 403', r.status === 403);

  /* ۲۱ — خروج */
  cookieJar = '';
  await req('POST', '/api/auth/login', { username: 'admin', password: 'newpass99' });
  r = await req('POST', '/api/auth/logout');
  check('خروج → 200', r.status === 200);
  cookieJar = '';
  r = await req('GET', '/api/db');
  check('پس از خروج /api/db → 401', r.status === 401);

  /* ۲۲ — لاگین مجدد پس از همه تغییرات */
  r = await req('POST', '/api/auth/login', { username: 'admin', password: 'newpass99' });
  check('لاگین مجدد پس از همه تغییرات', r.status === 200, r);

  /* ۲۳ — لاگ سیستم: دسترسی */
  cookieJar = '';
  r = await req('GET', '/api/syslog');
  check('GET /api/syslog بدون نشست → 401', r.status === 401);
  /* ورود admin و افزودن کاربر غیرمدیر تازه (حساب ceo در آزمون ۱۹ قفل شده است) */
  await req('POST', '/api/auth/login', { username: 'admin', password: 'newpass99' });
  r = await req('GET', '/api/db');
  const docV = r.json.doc;
  docV.users.push({ id: 'u9', fn: 'ناظر', ln: 'تست', uno: '2001', username: 'viewer', pos: 'ناظر', mgmtId: '', unitId: '', role: 'ceo', roles: ['ceo'], active: true, avatar: '', ph: hashStr('v12345' + 'viewer') });
  r = await req('PUT', '/api/db', { doc: docV, baseVersion: r.json.version });
  check('افزودن کاربر غیرمدیر برای آزمون دسترسی → 200', r.status === 200, r.json);
  r = await req('POST', '/api/users/setpass', { username: 'viewer', password: 'v12345' });
  check('تعیین رمز کاربر غیرمدیر → 200', r.status === 200);
  cookieJar = '';
  r = await req('POST', '/api/auth/login', { username: 'viewer', password: 'v12345' });
  check('ورود viewer → 200', r.status === 200, r.json);
  r = await req('GET', '/api/syslog');
  check('GET /api/syslog با نقش غیرمدیر → 403', r.status === 403, r.status);
  r = await req('POST', '/api/syslog/purge', {});
  check('POST /api/syslog/purge با نقش غیرمدیر → 403', r.status === 403, r.status);
  cookieJar = '';
  await req('POST', '/api/auth/login', { username: 'admin', password: 'newpass99' });

  /* ۲۴ — لاگ سیستم: داده‌ها و فیلترها */
  r = await req('GET', '/api/syslog?pageSize=50');
  check('GET /api/syslog (مدیر) → 200 با ساختار کامل', r.status === 200 && r.json.ok && Array.isArray(r.json.rows) && Array.isArray(r.json.meta.actions) && r.json.retentionDays === 60, r.json && r.json.retentionDays);
  check('لاگ شامل رخدادهای پیشین است (Bootstrap/LoginSuccess/SaveDoc)',
    r.json.rows.some(x => x.action === 'SaveDoc') && r.json.meta.actions.some(a => a.action === 'LoginSuccess'));
  const total1 = r.json.stats.total;
  r = await req('GET', '/api/syslog?action=SaveDoc');
  check('فیلتر نوع فعالیت → همه ردیف‌ها SaveDoc', r.status === 200 && r.json.rows.every(x => x.action === 'SaveDoc') && r.json.total > 0);
  r = await req('GET', '/api/syslog?outcome=fail');
  check('فیلتر نتیجه ناموفق → فقط ناموفق‌ها', r.status === 200 && r.json.rows.every(x => x.success === false) && r.json.total > 0);
  r = await req('GET', '/api/syslog?username=ceo');
  check('فیلتر کاربر → فقط ceo', r.status === 200 && r.json.rows.every(x => x.username === 'ceo'));
  r = await req('GET', '/api/syslog?q=' + encodeURIComponent('بازنویسی'));
  check('فیلتر جستجوی متنی (بازنویسی اجباری) → یافت شد', r.status === 200 && r.json.total > 0, r.json.total);
  r = await req('GET', '/api/syslog?page=1&pageSize=10');
  check('صفحه‌بندی → حداکثر ۱۰ ردیف با متادیتا', r.status === 200 && r.json.rows.length <= 10 && r.json.page === 1, r.json && r.json.rows.length);

  /* ۲۵ — پاکسازی لاگ: رفتار نگهداری ۶۰ روزه */
  r = await req('POST', '/api/syslog/purge', {});
  check('پاکسازی دستی (هیچ رکوردی قدیمی‌تر از ۶۰ روز نیست) → deleted=0', r.status === 200 && r.json.ok && r.json.deleted === 0, r.json);
  /* شبیه‌سازی رکورد ۶۱ روزه: درج مستقیم در فروشگاه و قدیمی‌کردن زمان آن (فقط فروشگاه حافظه) */
  if (store.kind === 'memory' && store.backdateAuditForTest) {
    const oldAt = new Date(Date.now() - 61 * 24 * 3600 * 1000).toISOString();
    await store.audit({ username: 'olduser', action: 'LoginSuccess', success: true, detail: 'رکورد قدیمی آزمون', ip: '127.0.0.1' });
    const backdated = store.backdateAuditForTest('olduser', oldAt);
    r = await req('POST', '/api/syslog/purge', {});
    check('پاکسازی رکورد ۶۱ روزه → حذف شد', backdated && r.status === 200 && r.json.ok && r.json.deleted === 1, r.json);
    const oldGone = await store.queryAudit({ username: 'olduser', pageSize: 10 });
    check('پس از پاکسازی، رکورد قدیمی دیگر در لاگ نیست', oldGone.rows.length === 0);
  } else {
    r = await req('POST', '/api/syslog/purge', {});
    check('پاکسازی اجرا شد (بدون تزریق رکورد قدیمی)', r.status === 200 && r.json.ok);
  }
  r = await req('GET', '/api/syslog?pageSize=1');
  check('لاگ پس از پاکسازی سالم است و ثبت ادامه دارد', r.status === 200 && r.json.ok);
  r = await req('GET', '/api/syslog?action=LogPurge');
  check('خودِ پاکسازی در لاگ ثبت شد (LogPurge)', r.status === 200 && r.json.total > 0, r.json.total);

  console.log('──────────────────────────────');
  console.log('پاس شد: ' + passed + ' | شکست: ' + failed);
  server.close();
  await store.close();
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('SELFTEST CRASH:', e); process.exit(1); });
