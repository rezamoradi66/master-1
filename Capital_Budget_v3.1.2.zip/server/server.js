#!/usr/bin/env node
/* ================================================================
   server.js — سامانه مدیریت بودجه سرمایه‌ای (لایه میانی SQL Server)
   نقش: سرویس‌دهی رابط کاربری + API امن روی شبکه داخلی، اتصال به SQL Server
   اجرا:  node server.js        (پیکربندی: config.json)
   ================================================================ */
'use strict';
const path = require('path');
const fs = require('fs');
const express = require('express');

const cfgMod = require('./lib/config');
const log = require('./lib/log');

let cfg;
try {
  cfg = cfgMod.load();
} catch (e) {
  console.error('══════════════════════════════════════════════');
  console.error('خطای پیکربندی: ' + e.message);
  console.error('فایل server/config.json را مطابق راهنمای PDF تکمیل کنید.');
  console.error('══════════════════════════════════════════════');
  process.exit(1);
}
log.init(cfg.logs);

let store;
if (cfg.store === 'memory') {
  console.error('⚠ حالت فروشگاه درون‌حافظه فعال است — فقط برای تست؛ داده‌ها پایدار نیستند.');
  store = require('./lib/store-memory').createMemoryStore(cfg);
} else {
  store = require('./lib/store-sql').createSqlStore(cfg);
}

const { createRouter } = require('./lib/routes');
const app = express();

/* بدنه JSON — سقف از پیکربندی */
app.use(express.json({ limit: cfg.security.maxBodyMB + 'mb' }));

/* API */
app.use(createRouter({ store, cfg }));

/* فایل‌های رابط کاربری */
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
app.use(express.static(PUBLIC_DIR, {
  etag: true,
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
  }
}));

/* مسیر ناشناخته → صفحه اصلی */
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, error: 'مسیر یافت نشد' });
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

/* مدیریت خطای عمومی */
app.use((err, req, res, next) => {
  log.error('unhandled: ' + (err && err.stack ? err.stack.split('\n')[0] : err));
  if (res.headersSent) return;
  res.status(500).json({ ok: false, error: 'خطای داخلی سرور' });
});

(async () => {
  try {
    await store.init();
  } catch (e) {
    console.error('══════════════════════════════════════════════');
    console.error('اتصال به SQL Server برقرار نشد: ' + (e && e.message));
    console.error('پیکربندی اتصال: server=' + cfg.sql.server + ' port=' + cfg.sql.port + ' db=' + cfg.sql.database + ' auth=' + cfg.sql.authType);
    console.error('راهنمای عیب‌یابی: بخش ۱۲ راهنمای PDF (فایروال، TCP/IP، حساب کاربری SQL).');
    console.error('══════════════════════════════════════════════');
    process.exit(1);
  }

  const server = app.listen(cfg.port, cfg.bindHost, () => {
    log.info('سامانه آماده سرویس‌دهی است → http://' + (cfg.bindHost === '0.0.0.0' ? '<IP-سرور>' : cfg.bindHost) + ':' + cfg.port);
    log.info('فروشگاه داده: ' + store.kind + ' | پایگاه: ' + cfg.sql.database);
  });

  const shutdown = async (sig) => {
    log.info('دریافت ' + sig + ' — خاموشی منظم...');
    try { server.close(); } catch (e) {}
    try { await store.close(); } catch (e) {}
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
})().catch(e => {
  log.error('راه‌اندازی ناموفق: ' + (e && e.message));
  process.exit(1);
});
